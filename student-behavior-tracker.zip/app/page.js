import HomePage from "@/templates/HomePage";

export default function Home() {
  return <HomePage />;
}
