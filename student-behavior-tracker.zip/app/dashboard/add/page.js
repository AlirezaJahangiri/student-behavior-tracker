import AddProfilePage from "@/templates/AddProfilePage";

function AddProfile() {
  return <AddProfilePage />;
}

export default AddProfile;
