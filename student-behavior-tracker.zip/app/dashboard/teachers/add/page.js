import AddTeacherPage from "@/templates/AddTeacherPage";
function AddTeacher() {
  return <AddTeacherPage />;
}

export default AddTeacher;
